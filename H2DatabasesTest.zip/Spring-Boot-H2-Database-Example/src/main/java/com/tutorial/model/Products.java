package com.tutorial.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Products {
	@Id
	private int id;
	private String productName;
	private String productDescription;
	private String productType;
	private double price;
	
	public int getId() {
		return id;
	}
	public String getProductName() {
		return productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public String getProductType() {
		return productType;
	}
	public double getPrice() {
		return price;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public void setPrice(double price) {
		this.price = price;
	}	
}
