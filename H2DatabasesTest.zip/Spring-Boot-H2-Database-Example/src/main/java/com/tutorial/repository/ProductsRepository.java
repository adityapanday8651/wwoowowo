package com.tutorial.repository;

import org.springframework.data.repository.CrudRepository;

import com.tutorial.model.Products;

public interface ProductsRepository extends CrudRepository<Products,Integer>{

}
